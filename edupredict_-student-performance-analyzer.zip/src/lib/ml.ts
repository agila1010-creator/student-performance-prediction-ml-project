import MultivariateLinearRegression from 'ml-regression-multivariate-linear';
import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';

export interface StudentData {
  studyHours: number;
  attendance: number;
  prevScore: number;
  sleepHours: number;
  participation: number; // 0-2
  assignments: number; // 0-100
  screenTime: number; // 0-10
  extracurricular: number; // 0-2
}

export interface PredictionResult {
  predictedScore: number;
  grade: string;
  message: string;
  suggestions: string[];
  contributions: { name: string; value: number }[];
  riskLevel: 'Safe Zone' | 'Moderate Risk' | 'High Risk';
  dnaLabel: 'Focused Learner' | 'Balanced Performer' | 'Needs Improvement';
}

export interface ModelStats {
  r2: number;
  mae: number;
  featureImportance: { name: string; weight: number }[];
  trainedWith: 'Dataset' | 'Formula';
}

let model: MultivariateLinearRegression;
let stats: ModelStats;

const FEATURE_NAMES = [
  'Study Hours', 
  'Attendance', 
  'Prev Score', 
  'Sleep Hours', 
  'Participation',
  'Assignments',
  'Screen Time',
  'Extracurricular'
];

/**
 * Fuzzy matches Kaggle column names to our features
 */
function findColumn(headers: string[], pattern: RegExp): string | undefined {
  return headers.find(h => pattern.test(h.toLowerCase().replace(/[\s_-]/g, '')));
}

function loadDataset() {
  const dataDir = path.join(process.cwd(), 'data');
  if (!fs.existsSync(dataDir)) return null;

  const files = fs.readdirSync(dataDir).filter(f => f.endsWith('.csv'));
  if (files.length === 0) return null;

  // Prefer student_data.csv, otherwise take the first available CSV
  const targetFile = files.find(f => f === 'student_data.csv') || files[0];
  const filePath = path.join(dataDir, targetFile);

  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      cast: true
    });

    if (records.length < 10) return null;

    const headers = Object.keys(records[0]);
    const maps = {
      study: findColumn(headers, /studyhour|studytime/) || headers.find(h => /study/i.test(h)),
      attend: findColumn(headers, /attendance|absences/) || headers.find(h => /attend/i.test(h)),
      prev: findColumn(headers, /previousscore|prevexam|g1|g2/) || headers.find(h => /prev/i.test(h)),
      sleep: findColumn(headers, /sleephour|sleep/) || headers.find(h => /sleep/i.test(h)),
      part: findColumn(headers, /participation/) || headers.find(h => /part/i.test(h)),
      assign: findColumn(headers, /assignment|homework/) || headers.find(h => /assign/i.test(h)),
      screen: findColumn(headers, /screentime/) || headers.find(h => /screen/i.test(h)),
      extra: findColumn(headers, /extracurricular/) || headers.find(h => /extra/i.test(h)),
      score: findColumn(headers, /score|grade|target|g3/) || headers.find(h => /score|grade/i.test(h))
    };

    const X: number[][] = [];
    const Y: number[][] = [];

    for (const row of records as any[]) {
      const xRow = [
        row[maps.study || ''] || 0,
        row[maps.attend || ''] || 0,
        row[maps.prev || ''] || 0,
        row[maps.sleep || ''] || 0,
        row[maps.part || ''] || 0,
        row[maps.assign || ''] || 0,
        row[maps.screen || ''] || 0,
        row[maps.extra || ''] || 0
      ];
      // Normalize negative relationships like 'absences'
      if (maps.attend?.includes('absences')) xRow[1] = Math.max(0, 100 - xRow[1]);
      
      X.push(xRow);
      Y.push([row[maps.score || ''] || 0]);
    }

    return { X, Y, source: targetFile };
  } catch (err) {
    console.error('Error loading dataset:', err);
    return null;
  }
}

export function trainModel() {
  const dataset = loadDataset();
  
  if (!dataset) {
    console.warn('Using formula fallback - No valid Kaggle dataset found in /data');
    stats = { r2: 1.0, mae: 0, featureImportance: [], trainedWith: 'Formula' };
    return;
  }

  const { X, Y, source } = dataset;
  model = new MultivariateLinearRegression(X, Y);

  const predictions = model.predict(X);
  let totalError = 0;
  for (let i = 0; i < predictions.length; i++) {
    totalError += Math.abs(predictions[i][0] - Y[i][0]);
  }
  const mae = totalError / predictions.length;
  
  const meanY = Y.reduce((acc, val) => acc + val[0], 0) / Y.length;
  let ssRes = 0, ssTot = 0;
  for (let i = 0; i < Y.length; i++) {
    ssRes += Math.pow(Y[i][0] - predictions[i][0], 2);
    ssTot += Math.pow(Y[i][0] - meanY, 2);
  }
  const r2 = 1 - (ssRes / ssTot);

  const weights = model.weights;
  const featureImportance = FEATURE_NAMES.map((name, i) => ({
    name,
    weight: Math.abs(weights[i + 1][0])
  })).sort((a, b) => b.weight - a.weight);

  stats = { r2, mae, featureImportance, trainedWith: 'Dataset' };
  console.log(`Model trained on ${source}. R2: ${r2.toFixed(3)}`);
}

export function predict(data: StudentData): PredictionResult {
  if (!stats) trainModel();

  let score: number;
  let contributions: { name: string; value: number }[] = [];

  if (stats.trainedWith === 'Dataset' && model) {
    const input = [
      data.studyHours, data.attendance, data.prevScore, 
      data.sleepHours, data.participation, data.assignments, 
      data.screenTime, data.extracurricular
    ];
    const result = model.predict([input])[0][0];
    score = Math.max(0, Math.min(100, Math.round(result * 10) / 10));

    const weights = model.weights;
    contributions = FEATURE_NAMES.map((name, i) => {
      const weight = weights[i + 1][0];
      return { name, value: Math.round(input[i] * weight * 100) / 100 };
    });
  } else {
    // Formula Fallback
    const studyImpact = data.studyHours * 5;
    const attendanceImpact = data.attendance * 0.3;
    const prevScoreImpact = data.prevScore * 0.4;
    const sleepImpact = data.sleepHours * 3;
    const assignmentImpact = Math.max(0, data.assignments * 0.25);
    const screenImpact = -(data.screenTime * 2);
    
    score = studyImpact + attendanceImpact + prevScoreImpact + sleepImpact + assignmentImpact + screenImpact;
    score = Math.max(0, Math.min(100, Math.round(score * 10) / 10));

    contributions = [
      { name: 'Study Hours', value: studyImpact },
      { name: 'Attendance', value: attendanceImpact },
      { name: 'Prev Score', value: prevScoreImpact },
      { name: 'Sleep Hours', value: sleepImpact },
      { name: 'Assignments', value: assignmentImpact },
      { name: 'Screen Time', value: screenImpact },
    ];
  }

  const isHighPerformance = score >= 75;
  const isAtRisk = score < 50;

  return {
    predictedScore: score,
    grade: score >= 90 ? 'A' : score >= 75 ? 'B' : score >= 50 ? 'C' : 'D',
    message: isHighPerformance ? "Excellent potential! Historical trends support your current habits." :
            isAtRisk ? "Warning: Performance indicators are below target levels." :
            "Steady progress. Minor adjustments could lead to significantly better outcomes.",
    suggestions: [
      data.studyHours < 6 ? "A significant correlation exists between study hours and top marks." : "",
      data.screenTime > 4 ? "Reducing screen time is historically linked to higher GPA." : "",
      data.attendance < 85 ? "Attendance consistency is the primary driver of success in similar datasets." : ""
    ].filter(Boolean),
    contributions,
    riskLevel: score < 50 ? 'High Risk' : score < 70 ? 'Moderate Risk' : 'Safe Zone',
    dnaLabel: data.studyHours > 8 ? 'Focused Learner' : score < 55 ? 'Needs Improvement' : 'Balanced Performer'
  };
}

export function calculateGoal(targetScore: number, current: StudentData) {
  const currentResult = predict(current);
  const currentScore = currentResult.predictedScore;
  
  if (targetScore <= currentScore) {
    return { alreadyAchieved: true, message: "You are already meeting your target score based on the model's analysis." };
  }

  const gap = targetScore - currentScore;
  
  // Weights based on target feature impact
  return {
    alreadyAchieved: false,
    requiredStudy: Math.round(Math.min(12, current.studyHours + (gap / 5)) * 10) / 10,
    requiredAttendance: Math.round(Math.min(100, current.attendance + (gap / 0.3)) * 10) / 10,
    requiredSleep: Math.round(Math.min(10, current.sleepHours + (gap / 3)) * 10) / 10,
    requiredScreenTime: Math.round(Math.max(0, current.screenTime - (gap / 2)) * 10) / 10,
    message: `To achieve your target score of ${targetScore}% based on model trends:`
  };
}

export function getStats() {
  if (!stats) trainModel();
  return stats;
}
