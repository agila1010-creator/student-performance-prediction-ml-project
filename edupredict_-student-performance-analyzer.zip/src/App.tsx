import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, GraduationCap, Clock, Users, Moon, Sun, RotateCcw, TrendingUp, Info,
  CheckCircle2, AlertCircle, BrainCircuit, BarChart3, Monitor, ClipboardCheck,
  Trophy, Sparkles, Zap, Target, History, Upload, Download, LayoutDashboard,
  ChevronRight, HelpCircle, ArrowUpRight, ArrowDownRight, FileText
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, 
  Cell, RadarChart, PolarGrid, PolarAngleAxis, Radar, LineChart, Line, PieChart, Pie
} from 'recharts';
import { cn } from './lib/utils';
import Papa from 'papaparse';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

interface PredictionResult {
  predictedScore: number;
  grade: string;
  message: string;
  suggestions: string[];
  contributions: { name: string; value: number }[];
  riskLevel: 'Safe Zone' | 'Moderate Risk' | 'High Risk';
  dnaLabel: 'Focused Learner' | 'Balanced Performer' | 'Needs Improvement';
}

interface ModelStats {
  r2: number;
  mae: number;
  featureImportance: { name: string; weight: number }[];
}

interface HistoryItem extends PredictionResult {
  timestamp: number;
  inputs: any;
}

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark';
    }
    return false;
  });
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history' | 'bulk' | 'goals'>('dashboard');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [stats, setStats] = useState<ModelStats | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [targetScore, setTargetScore] = useState(85);
  const [goalResult, setGoalResult] = useState<any>(null);
  const [bulkResults, setBulkResults] = useState<any[]>([]);
  
  const [exporting, setExporting] = useState(false);
  
  const [formData, setFormData] = useState({
    studyHours: 8,
    attendance: 85,
    prevScore: 75,
    sleepHours: 7,
    participation: 1,
    assignments: 90,
    screenTime: 3,
    extracurricular: 1,
  });

  const dashboardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  useEffect(() => {
    const savedHistory = localStorage.getItem('edu_history');
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/model-stats');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats', err);
    }
  };

  const runPrediction = useCallback(async (data = formData, saveToHistory = true) => {
    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const prediction = await res.json();
      setResult(prediction);
      
      if (saveToHistory) {
        const newHistory = [{ ...prediction, timestamp: Date.now(), inputs: data }, ...history].slice(0, 20);
        setHistory(newHistory);
        localStorage.setItem('edu_history', JSON.stringify(newHistory));
      }
    } catch (err) {
      console.error('Prediction failed', err);
    }
  }, [formData, history]);

  // Real-time prediction
  useEffect(() => {
    const timer = setTimeout(() => {
      runPrediction(formData, false);
    }, 300);
    return () => clearTimeout(timer);
  }, [formData, runPrediction]);

  // Real-time goal calculation
  useEffect(() => {
    if (activeTab === 'goals') {
      const timer = setTimeout(() => {
        handleGoalCalculate();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [targetScore, formData, activeTab]);

  const handleGoalCalculate = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/calculate-goal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetScore, current: formData }),
      });
      const data = await res.json();
      setGoalResult(data);
    } catch (err) {
      console.error('Goal calculation failed', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: async (results) => {
        const processed = [];
        for (const row of results.data as any[]) {
          if (!row.study_hours) continue;
          const data = {
            studyHours: row.study_hours || 0,
            attendance: row.attendance || 0,
            prevScore: row.previous_score || 0,
            sleepHours: row.sleep || 0,
            participation: row.participation === 'High' ? 2 : row.participation === 'Medium' ? 1 : 0,
            assignments: row.assignments || 0,
            screenTime: row.screen_time || 0,
            extracurricular: row.extracurricular === 'High' ? 2 : row.extracurricular === 'Moderate' ? 1 : 0,
          };
          const res = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          const pred = await res.json();
          processed.push({ ...row, ...pred });
        }
        setBulkResults(processed);
        setActiveTab('bulk');
      }
    });
  };

  const exportPDF = async () => {
    if (!dashboardRef.current) {
      alert("Please switch to the Dashboard tab to export the full report.");
      return;
    }
    setExporting(true);
    try {
      const canvas = await html2canvas(dashboardRef.current, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: isDarkMode ? '#0a0c14' : '#f8fafc'
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      // Handle multi-page if content is too long
      let heightLeft = pdfHeight;
      let position = 0;
      const pageHeight = pdf.internal.pageSize.getHeight();

      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - pdfHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pageHeight;
      }

      pdf.save('EduPredict_Report.pdf');
    } catch (err) {
      console.error('PDF Export failed', err);
      alert("Failed to generate PDF. Please try again.");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className={cn(
      "min-h-screen transition-colors duration-500 selection:bg-indigo-500/30 font-sans",
      isDarkMode ? "bg-[#0a0c14] text-slate-100" : "bg-slate-50 text-slate-900"
    )}>
      {/* Sidebar / Navigation */}
      <nav className={cn(
        "fixed left-0 top-0 bottom-0 w-20 lg:w-64 z-50 border-r transition-all duration-300 flex flex-col",
        isDarkMode ? "bg-slate-950/80 border-slate-800/50" : "bg-white/80 border-slate-200/50",
        "backdrop-blur-xl"
      )}>
        <div className="p-6 flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-xl shadow-lg shadow-indigo-500/20 shrink-0">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <span className="hidden lg:block font-black text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">
            EduPredict 3.0
          </span>
        </div>

        <div className="flex-1 px-4 py-6 space-y-2">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
            { id: 'history', icon: History, label: 'History' },
            { id: 'bulk', icon: Upload, label: 'Bulk Analysis' },
            { id: 'goals', icon: Target, label: 'Goal Planner' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-3 p-3 rounded-xl transition-all group",
                activeTab === item.id 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20" 
                  : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              )}
            >
              <item.icon className={cn("w-5 h-5", activeTab === item.id ? "text-white" : "group-hover:text-indigo-500")} />
              <span className="hidden lg:block font-bold text-sm">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="w-full flex items-center gap-3 p-3 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-yellow-400" /> : <Moon className="w-5 h-5" />}
            <span className="hidden lg:block font-bold text-sm">{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="pl-20 lg:pl-64 min-h-screen">
        <header className="h-20 px-8 flex items-center justify-between sticky top-0 z-40 backdrop-blur-md">
          <h2 className="text-xl font-black capitalize">{activeTab}</h2>
          <div className="flex items-center gap-4">
            <label className="cursor-pointer p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all flex items-center gap-2">
              <Upload className="w-4 h-4" />
              <span className="text-xs font-bold hidden sm:block">Import CSV</span>
              <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
            </label>
            <button 
              onClick={exportPDF}
              disabled={exporting}
              className={cn(
                "p-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs flex items-center gap-2 hover:opacity-90 transition-all",
                exporting && "opacity-50 cursor-not-allowed"
              )}
            >
              {exporting ? (
                <RotateCcw className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span className="hidden sm:block">{exporting ? 'Generating...' : 'Export Report'}</span>
            </button>
          </div>
        </header>

        <main className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                ref={dashboardRef}
                className="grid grid-cols-1 xl:grid-cols-12 gap-8"
              >
                {/* Left Column: Inputs */}
                <div className="xl:col-span-4 space-y-6">
                  <div className={cn(
                    "p-6 rounded-3xl border shadow-sm",
                    isDarkMode ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200"
                  )}>
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-black flex items-center gap-2">
                        <BrainCircuit className="w-5 h-5 text-indigo-500" />
                        Student Profile
                      </h3>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Live Simulator</span>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      {[
                        { id: 'studyHours', label: 'Study Hours', icon: Clock, max: 12, step: 0.5, unit: 'h', color: 'indigo' },
                        { id: 'attendance', label: 'Attendance', icon: Users, max: 100, step: 1, unit: '%', color: 'emerald' },
                        { id: 'sleepHours', label: 'Sleep Hours', icon: Moon, max: 10, step: 0.5, unit: 'h', color: 'blue' },
                        { id: 'screenTime', label: 'Screen Time', icon: Monitor, max: 10, step: 0.5, unit: 'h', color: 'rose' },
                        { id: 'assignments', label: 'Assignments', icon: ClipboardCheck, max: 100, step: 1, unit: '%', color: 'violet' },
                      ].map((field) => (
                        <div key={field.id} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <label className="text-xs font-bold text-slate-500 uppercase flex items-center gap-2">
                              <field.icon className="w-3.5 h-3.5" />
                              {field.label}
                            </label>
                            <span className={cn("text-xs font-black px-2 py-0.5 rounded-md bg-opacity-10", `bg-${field.color}-500 text-${field.color}-500`)}>
                              {(formData as any)[field.id]}{field.unit}
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max={field.max}
                            step={field.step}
                            value={(formData as any)[field.id]}
                            onChange={(e) => setFormData({ ...formData, [field.id]: parseFloat(e.target.value) })}
                            className={cn("w-full h-1.5 rounded-full appearance-none cursor-pointer", `accent-${field.color}-500 bg-slate-200 dark:bg-slate-800`)}
                          />
                        </div>
                      ))}

                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase">Previous Score</label>
                        <input
                          type="number"
                          value={formData.prevScore}
                          onChange={(e) => setFormData({ ...formData, prevScore: parseInt(e.target.value) || 0 })}
                          className={cn(
                            "w-full p-3 rounded-xl border font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none",
                            isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Participation</label>
                          <select
                            value={formData.participation}
                            onChange={(e) => setFormData({ ...formData, participation: parseInt(e.target.value) })}
                            className={cn(
                              "w-full p-2.5 rounded-xl border font-bold text-xs",
                              isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
                            )}
                          >
                            <option value={0}>Low</option>
                            <option value={1}>Medium</option>
                            <option value={2}>High</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Activities</label>
                          <select
                            value={formData.extracurricular}
                            onChange={(e) => setFormData({ ...formData, extracurricular: parseInt(e.target.value) })}
                            className={cn(
                              "w-full p-2.5 rounded-xl border font-bold text-xs",
                              isDarkMode ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"
                            )}
                          >
                            <option value={0}>None</option>
                            <option value={1}>Moderate</option>
                            <option value={2}>High</option>
                          </select>
                        </div>
                      </div>

                      <div className="pt-4 flex gap-3">
                        <button 
                          onClick={() => runPrediction(formData, true)}
                          className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-black text-sm hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2"
                        >
                          <Zap className="w-4 h-4" />
                          Save to History
                        </button>
                        <button 
                          onClick={() => setFormData({
                            studyHours: 8,
                            attendance: 85,
                            prevScore: 75,
                            sleepHours: 7,
                            participation: 1,
                            assignments: 90,
                            screenTime: 3,
                            extracurricular: 1,
                          })}
                          className={cn(
                            "p-3 rounded-xl border transition-all",
                            isDarkMode ? "border-slate-700 hover:bg-slate-800" : "border-slate-200 hover:bg-slate-100"
                          )}
                        >
                          <RotateCcw className="w-4 h-4 text-slate-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Column: Results & Analytics */}
                <div className="xl:col-span-8 space-y-8">
                  {result && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Main Score Card */}
                      <div className={cn(
                        "p-8 rounded-[2.5rem] border shadow-lg relative overflow-hidden group",
                        isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                      )}>
                        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16" />
                        <div className="relative z-10 space-y-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Predicted Score</p>
                              <div className="flex items-baseline gap-2">
                                <span className="text-6xl font-black bg-clip-text text-transparent bg-gradient-to-br from-indigo-500 to-violet-500">
                                  {result.predictedScore}
                                </span>
                                <span className="text-xl font-bold text-slate-300">/100</span>
                              </div>
                            </div>
                            <div className={cn(
                              "w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-black shadow-inner",
                              isDarkMode ? "bg-slate-800" : "bg-slate-100"
                            )}>
                              {result.grade}
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider",
                              result.riskLevel === 'Safe Zone' ? "bg-emerald-500/10 text-emerald-500" :
                              result.riskLevel === 'Moderate Risk' ? "bg-amber-500/10 text-amber-500" :
                              "bg-rose-500/10 text-rose-500"
                            )}>
                              {result.riskLevel}
                            </div>
                            <div className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-500 text-[10px] font-black uppercase tracking-wider">
                              {result.dnaLabel}
                            </div>
                          </div>

                          <p className="text-sm font-medium text-slate-500 italic">"{result.message}"</p>
                        </div>
                      </div>

                      {/* DNA Radar Chart */}
                      <div className={cn(
                        "p-6 rounded-[2.5rem] border shadow-lg",
                        isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                      )}>
                        <h4 className="text-xs font-black text-slate-400 uppercase mb-4">Student DNA Profile</h4>
                        <div className="h-[200px] w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={[
                              { subject: 'Study', A: (formData.studyHours / 12) * 100 },
                              { subject: 'Attend', A: formData.attendance },
                              { subject: 'Sleep', A: (formData.sleepHours / 10) * 100 },
                              { subject: 'Screen', A: 100 - (formData.screenTime / 10) * 100 },
                              { subject: 'Assign', A: formData.assignments },
                            ]}>
                              <PolarGrid stroke={isDarkMode ? '#334155' : '#e2e8f0'} />
                              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }} />
                              <Radar name="DNA" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.5} />
                            </RadarChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Explainable AI: Contributions */}
                  {result && (
                    <div className={cn(
                      "p-8 rounded-[2.5rem] border shadow-lg",
                      isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                    )}>
                      <h4 className="text-sm font-black text-slate-400 uppercase mb-6 flex items-center gap-2">
                        <Info className="w-4 h-4" />
                        Explainable AI: Feature Contributions
                      </h4>
                      <div className="h-[250px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={result.contributions} layout="vertical">
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                            <RechartsTooltip 
                              formatter={(value: number) => [`${value} marks`, 'Impact']}
                              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                            />
                            <Bar dataKey="value" radius={[0, 10, 10, 0]}>
                              {result.contributions.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.value >= 0 ? '#10b981' : '#f43f5e'} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}

                  {/* Recommendations */}
                  {result && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {result.suggestions.map((s, i) => (
                        <div key={i} className={cn(
                          "p-4 rounded-2xl border flex gap-3 items-start",
                          isDarkMode ? "bg-slate-800/50 border-slate-700" : "bg-slate-50 border-slate-200"
                        )}>
                          <div className="p-2 bg-indigo-500/10 rounded-lg shrink-0">
                            <Sparkles className="w-4 h-4 text-indigo-500" />
                          </div>
                          <p className="text-xs font-bold text-slate-500 leading-relaxed">{s}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Additional Analytics */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Effort Distribution */}
                    <div className={cn(
                      "p-6 rounded-[2.5rem] border shadow-lg",
                      isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                    )}>
                      <h4 className="text-xs font-black text-slate-400 uppercase mb-4">Effort Distribution</h4>
                      <div className="h-[200px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={[
                                { name: 'Study', value: formData.studyHours * 2 },
                                { name: 'Assignments', value: formData.assignments / 10 },
                                { name: 'Attendance', value: formData.attendance / 10 },
                                { name: 'Activities', value: (formData.extracurricular + 1) * 5 },
                              ]}
                              cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value"
                            >
                              <Cell fill="#6366f1" />
                              <Cell fill="#10b981" />
                              <Cell fill="#f59e0b" />
                              <Cell fill="#ec4899" />
                            </Pie>
                            <RechartsTooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Improvement Trend */}
                    <div className={cn(
                      "p-6 rounded-[2.5rem] border shadow-lg",
                      isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                    )}>
                      <h4 className="text-xs font-black text-slate-400 uppercase mb-4">Improvement Trend</h4>
                      <div className="h-[200px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={[...history].reverse()}>
                            <XAxis dataKey="timestamp" hide />
                            <YAxis hide domain={[0, 100]} />
                            <RechartsTooltip labelFormatter={(t) => new Date(t).toLocaleTimeString()} />
                            <Line type="monotone" dataKey="predictedScore" stroke="#6366f1" strokeWidth={3} dot={{ r: 4, fill: '#6366f1' }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'history' && (
              <motion.div 
                key="history"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-2xl font-black">Prediction History</h3>
                  <button 
                    onClick={() => { setHistory([]); localStorage.removeItem('edu_history'); }}
                    className="text-xs font-bold text-rose-500 hover:underline"
                  >
                    Clear All
                  </button>
                </div>
                
                {history.length === 0 ? (
                  <div className="p-12 text-center border-2 border-dashed rounded-3xl border-slate-200 dark:border-slate-800">
                    <History className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 font-bold">No history available yet.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {history.map((item, i) => (
                      <div key={i} className={cn(
                        "p-6 rounded-2xl border flex flex-wrap items-center justify-between gap-6",
                        isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                      )}>
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-12 h-12 rounded-xl flex items-center justify-center text-xl font-black",
                            isDarkMode ? "bg-slate-800" : "bg-slate-100"
                          )}>
                            {item.grade}
                          </div>
                          <div>
                            <p className="text-lg font-black">{item.predictedScore}%</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase">
                              {new Date(item.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          {Object.entries(item.inputs).map(([key, val]: any) => (
                            <div key={key} className="px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-bold">
                              {key.slice(0, 3)}: {val}
                            </div>
                          ))}
                        </div>

                        <button 
                          onClick={() => { setFormData(item.inputs); setActiveTab('dashboard'); }}
                          className="p-2 rounded-lg bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-all"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'bulk' && (
              <motion.div 
                key="bulk"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-2xl font-black">Bulk CSV Analysis</h3>
                  <div className="flex gap-3">
                    {bulkResults.length > 0 && (
                      <button 
                        onClick={() => setBulkResults([])}
                        className="px-4 py-2 bg-rose-500/10 text-rose-500 rounded-xl font-bold text-sm hover:bg-rose-500 hover:text-white transition-all flex items-center gap-2"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Remove CSV
                      </button>
                    )}
                    <label className="cursor-pointer px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Upload New CSV
                      <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
                    </label>
                  </div>
                </div>

                {bulkResults.length === 0 ? (
                  <div className="p-12 text-center border-2 border-dashed rounded-3xl border-slate-200 dark:border-slate-800">
                    <Upload className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 font-bold">Upload a CSV file to see bulk predictions.</p>
                    <p className="text-[10px] text-slate-400 mt-2 uppercase">Required: study_hours, attendance, previous_score, sleep, assignments</p>
                  </div>
                ) : (
                  <div className={cn(
                    "rounded-3xl border overflow-hidden",
                    isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                  )}>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className={cn("border-b", isDarkMode ? "border-slate-800 bg-slate-900/50" : "bg-slate-50/50 border-slate-200")}>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Student</th>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Study</th>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Attend</th>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Predicted</th>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Grade</th>
                            <th className="p-4 text-xs font-black uppercase text-slate-500 dark:text-slate-400">Risk</th>
                          </tr>
                        </thead>
                        <tbody>
                          {bulkResults.map((row, i) => (
                            <tr 
                              key={i} 
                              className={cn(
                                "border-b transition-colors group",
                                isDarkMode 
                                  ? "border-slate-800/50 hover:bg-indigo-500/5" 
                                  : "border-slate-100 hover:bg-indigo-50/50"
                              )}
                            >
                              <td className="p-4 text-sm font-bold text-slate-700 dark:text-slate-300 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                                Student #{i + 1}
                              </td>
                              <td className="p-4 text-sm text-slate-600 dark:text-slate-400">{row.study_hours}h</td>
                              <td className="p-4 text-sm text-slate-600 dark:text-slate-400">{row.attendance}%</td>
                              <td className="p-4 text-sm font-black text-indigo-500">{row.predictedScore}%</td>
                              <td className="p-4 text-sm font-black text-slate-700 dark:text-slate-300">{row.grade}</td>
                              <td className="p-4">
                                <span className={cn(
                                  "px-2 py-1 rounded-md text-[10px] font-black uppercase",
                                  row.riskLevel === 'Safe Zone' ? "bg-emerald-500/10 text-emerald-500" :
                                  row.riskLevel === 'Moderate Risk' ? "bg-amber-500/10 text-amber-500" :
                                  "bg-rose-500/10 text-rose-500"
                                )}>
                                  {row.riskLevel}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'goals' && (
              <motion.div 
                key="goals"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-2xl mx-auto space-y-8"
              >
                <div className="text-center space-y-2">
                  <h3 className="text-3xl font-black">Goal Planner</h3>
                  <p className="text-slate-500 font-medium">Set your target score and we'll calculate the path.</p>
                </div>

                <div className={cn(
                  "p-8 rounded-[2.5rem] border shadow-xl",
                  isDarkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
                )}>
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-sm font-black text-slate-400 uppercase">Target Score</label>
                        <span className={cn(
                          "text-2xl font-black",
                          targetScore > 100 ? "text-rose-500" : "text-indigo-500"
                        )}>{targetScore}%</span>
                      </div>
                      <input 
                        type="range" min="50" max="110" step="1"
                        value={targetScore}
                        onChange={(e) => setTargetScore(parseInt(e.target.value))}
                        className="w-full h-2 rounded-full appearance-none cursor-pointer accent-indigo-600 bg-slate-200 dark:bg-slate-800"
                      />
                      {targetScore > 100 && (
                        <p className="text-[10px] font-bold text-rose-500 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          Target score cannot exceed 100%
                        </p>
                      )}
                    </div>
                  </div>

                  {goalResult && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-12 space-y-6"
                    >
                      <div className={cn(
                        "p-4 rounded-2xl flex items-center gap-3",
                        goalResult.alreadyAchieved 
                          ? "bg-emerald-500/10 text-emerald-500" 
                          : "bg-indigo-500/10 text-indigo-500"
                      )}>
                        {goalResult.alreadyAchieved ? <CheckCircle2 className="w-5 h-5" /> : <Target className="w-5 h-5" />}
                        <p className="text-sm font-black uppercase tracking-wider">{goalResult.message}</p>
                      </div>

                      {!goalResult.alreadyAchieved && targetScore <= 100 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {[
                            { label: 'Study Hours', value: goalResult.requiredStudy, unit: ' hrs/day', icon: Clock, color: 'indigo' },
                            { label: 'Attendance', value: goalResult.requiredAttendance, unit: '%', icon: Users, color: 'emerald' },
                            { label: 'Sleep', value: goalResult.requiredSleep, unit: ' hrs', icon: Moon, color: 'blue' },
                            { label: 'Screen Time', value: goalResult.requiredScreenTime, unit: ' hrs', icon: Monitor, color: 'rose' },
                          ].map((item) => (
                            <div key={item.label} className={cn(
                              "p-4 rounded-2xl border flex items-center justify-between",
                              isDarkMode ? "bg-slate-800/50 border-slate-700" : "bg-slate-50 border-slate-200"
                            )}>
                              <div className="flex items-center gap-3">
                                <div className={cn("p-2 rounded-lg bg-opacity-10", `bg-${item.color}-500 text-${item.color}-500`)}>
                                  <item.icon className="w-4 h-4" />
                                </div>
                                <span className="font-bold text-xs text-slate-500">{item.label}</span>
                              </div>
                              <span className="text-sm font-black">{item.value}{item.unit}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
