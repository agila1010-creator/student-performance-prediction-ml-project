# Place your Kaggle CSV files here.
# The app will automatically try to match columns like "StudyHours", "G3", "absences", etc.
